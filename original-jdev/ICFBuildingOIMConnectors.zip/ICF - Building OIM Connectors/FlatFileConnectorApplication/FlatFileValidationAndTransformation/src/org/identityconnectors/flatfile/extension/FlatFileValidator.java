package org.identityconnectors.flatfile.extension;
import java.util.HashMap;
public class FlatFileValidator{	
	public boolean validate(HashMap arg0, HashMap arg1, String arg2){
		String thisField = (String)arg0.get(arg2);
		System.out.println("Inside validate method...");
		return true;
	}

}