id=$1
firstName=$2
lastName=$3
email=$4
echo "**********Input values************"
echo "id: "$id
echo "First name:"=$firstName 
echo "Last name:"$lastName
echo "email: "$email
searchString="AccountId:"$id
echo "Account ID: "$searchString
content=`grep $searchString /scratch/mambuga/output.txt`
echo "content = "$content
if test "$content" != ""
then
echo "account already exists"
exit 1
else
echo "account with id $id does not exists, creating now.."
echo "email:$4,FirstName:$2,lastName:$3,AccountId:$1" >> /scratch/mambuga/output.txt
exit 0
fi
