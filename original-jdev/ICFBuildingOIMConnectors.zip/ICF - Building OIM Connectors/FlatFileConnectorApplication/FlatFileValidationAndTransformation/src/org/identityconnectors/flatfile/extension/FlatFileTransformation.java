package org.identityconnectors.flatfile.extension;

import java.util.HashMap;
public class FlatFileTransformation {
    public Object transform(HashMap arg0, HashMap arg1, String arg2){
		System.out.println("Returning same value "+arg2);
		return arg2;
	}

}
