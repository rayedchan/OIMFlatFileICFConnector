content=`cat /scratch/mambuga/output.txt`
echo $content
